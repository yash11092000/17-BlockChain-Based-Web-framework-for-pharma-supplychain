var web3;
var contract;

fetch("/public/data/contract_data.json").then((response) => {
  response.json().then((data) => {
    // console.log(data);
    var contract_address = data.contractAddress;
    var contract_abi = data.contractABI;

    web3 = new Web3(Web3.givenProvider || "ws://localhost:7545");
    contract = new web3.eth.Contract(contract_abi, contract_address);
  });
});

ethereum.request({
  method: "eth_requestAccounts",
});

var account;
//========================

var CreBtn = document.getElementById("CreateProd");
if (CreBtn) {
  CreBtn.addEventListener("click", function () {
    var id = Date.now();
    var name = document.getElementById("ProdName").value;
    var qty = document.getElementById("ProdQty").value;
    var measure = document.getElementById("qty").value;
    var owner = document.getElementById("ProdOwner").value;
    var buyer = document.getElementById("ProdBuyer").value;
    // console.log(qty + "" + measure);
    var quantity = qty + "" + measure;
    var currentdate = new Date();
    var datetime =
      "Last Sync: " +
      currentdate.getDate() +
      "/" +
      (currentdate.getMonth() + 1) +
      "/" +
      currentdate.getFullYear() +
      " @ " +
      currentdate.getHours() +
      ":" +
      currentdate.getMinutes() +
      ":" +
      currentdate.getSeconds();
    if (name.length != 0) {
      web3.eth.getAccounts().then(function (accounts) {
        account = accounts[0];
        console.log(account);
        contract.methods
          .CreatedProd(id, name, quantity, datetime, owner, buyer)
          .send({ from: account })
          .then(function (result) {
            console.log(result);
            swal(
              "Good job!",
              `You Product Is Created! and Your ID is ${id}`,
              "success"
            );
          })
          .catch(function (error) {
            console.log(error);
            swal("Oops!", "Something Went Wrong!", "danger");
          });
      });
    } else {
      swal(
        "OOPS!",
        "Try Entering Valid Id or Enter Some Text for Product Name",
        "danger"
      );
    }
  });
}

var fetchBtn = document.getElementById("FetchProd");
if (fetchBtn) {
  var ProdId = document.getElementById("prodId");
  var ProdName = document.getElementById("prodName");
  var ProdQuantity = document.getElementById("prodQty");
  var ProdCreatedDate = document.getElementById("prodCreatedDate");
  // var ProdIsPicked = document.getElementById("prodIsPicked");
  var ProdPickedDate = document.getElementById("prodPickedDate");
  // var ProdIsDelivered = document.getElementById("prodIsDelivered");
  var ProdDeliveredDate = document.getElementById("prodDeliveredDate");
  var ProdBuyer = document.getElementById("prodBuyer");
  var ProdOwner = document.getElementById("prodOwner");
  var ProdCustody = document.getElementById("prodCustody");
  fetchBtn.addEventListener("click", function () {
    // console.log("clicked")
    var id = document.getElementById("ProdId2").value;
    web3.eth.getAccounts().then(function (accounts) {
      account = accounts[0];
      // console.log(account)
      contract.methods
        .GetProd(id)
        .call({ from: account })
        .then(function (result) {
          // console.log(result.CreatedDate)
          console.log(result);
          // console.log(result.IsCreated);
          ProdId.innerText = result.ProdId;
          ProdName.innerText = result.ProdName;
          ProdQuantity.innerText = result.ProdQty;
          ProdCreatedDate.innerText = result.CreatedDate;
          // ProdIsPicked.innerText = "IsProductPicked:" + result.IsPicked;
          ProdPickedDate.innerText = result.PickedDate;
          ProdDeliveredDate.innerText = result.DeliveredDate;
          ProdBuyer.innerText = result.Buyer;
          ProdOwner.innerText = result.Owner;
          ProdCustody.innerText = result.CurrentCustody;
          // ProdIsDelivered.innerText ="IsProductDelived  :" + result.Isdelivered;
        })
        .catch(function (err) {
          swal("Oops!", "Product Not Found!", "danger");
        });
    });
  });
}

var TriggerDel = document.getElementById("TriggerDel");
if (TriggerDel) {
  console.log(TriggerDel);
  TriggerDel.addEventListener("click", function () {
    console.log(TriggerDel);
    var currentdate = new Date();
    var datetime =
      "Last Sync: " +
      currentdate.getDate() +
      "/" +
      (currentdate.getMonth() + 1) +
      "/" +
      currentdate.getFullYear() +
      " @ " +
      currentdate.getHours() +
      ":" +
      currentdate.getMinutes() +
      ":" +
      currentdate.getSeconds();
    var id = parseInt(document.getElementById("ProdId3").value);
    var iotid = parseInt(document.getElementById("ProdId4").value);
    var vehicleid = document.getElementById("ProdId5").value;
    if (id > 0 && iotid > 0) {
      web3.eth.getAccounts().then(function (accounts) {
        account = accounts[0];
        console.log(account);
        contract.methods
          .TriggerDelivery(id, datetime, vehicleid, iotid)
          .send({ from: account })
          .then(function (result) {
            console.log(result);
            swal("Nice!", "Product JourNey Started!", "success");
          })
          .catch(function (err) {
            console.log(
              "Sorry Some Error Occured OR Your Product ",
              id,
              "is Further in SupplyChain"
            );
            swal(
              "OOps!",
              "Product Is not present or Further In Chain",
              "danger"
            );
            console.log(error);
          });
      });
    } else {
      swal("OOps!", "Enter Valid Id", "danger");
    }
  });
}

var DeliveryStatus = document.getElementById("DeliveryStatus");
if (DeliveryStatus) {
  DeliveryStatus.addEventListener("click", function () {
    var currentdate = new Date();
    var datetime =
      "Last Sync: " +
      currentdate.getDate() +
      "/" +
      (currentdate.getMonth() + 1) +
      "/" +
      currentdate.getFullYear() +
      " @ " +
      currentdate.getHours() +
      ":" +
      currentdate.getMinutes() +
      ":" +
      currentdate.getSeconds();
    var id = parseInt(document.getElementById("ProdId4").value);

    web3.eth.getAccounts().then(function (accounts) {
      account = accounts[0];
      console.log(account);
      contract.methods
        .DeliveredDate(id, datetime)
        .send({ from: account })
        .then(function (result) {
          console.log(result);
          swal("Yay!", "Product Delivered", "success");
        })
        .catch(function (err) {
          console.log(err);
          swal("OOps!", "Product Is not present or Further In Chain", "danger");
        });
    });
  });
}

var historystatus = document.getElementById("GetHistory");
if (historystatus) {
  historystatus.addEventListener("click", function () {
    var id = document.getElementById("IotId").value;
    web3.eth.getAccounts().then(function (accounts) {
      account = accounts[0];

      contract.methods
        .getIOTData(id)
        .call({ from: account })
        .then(function (result) {
          console.log(result);
        })
        .catch(function (err) {
          console.log(err);
        });

      // contract.methods
      //   .GetProd(101)
      //   .call({ from: account })
      //   .then(function (result) {
      //     // console.log(result.CreatedDate)
      //     console.log(result);
      //   });
    });
  });
}

var form = document.getElementById("form-id");
if (form) {
  document.getElementById("btn-id").addEventListener("click", function () {
    form.submit();
  });
}
