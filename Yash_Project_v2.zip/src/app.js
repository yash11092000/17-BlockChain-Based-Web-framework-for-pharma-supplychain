require("dotenv").config();
const express = require("express");
const app = express();
const port = process.env.PORT || 3000;
const path = require("path");
const hbs = require("hbs");
const bcrypt = require("bcryptjs");
const auth = require("./middleware/auth");
const cookieparser = require("cookie-parser");
const fs = require("fs");
const fast2sms = require("fast-two-sms");
const alert = require("alert");

/////////////////
// Firebase Setup
var admin = require("firebase-admin");
var serviceAccount = require("../FirebaseKeys/fetchdata-830de-firebase-adminsdk-9bgm5-4c363cf208.json");
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://fetchdata-830de-default-rtdb.firebaseio.com",
});

const firebase_db = admin.database();
const firebase_dbref = firebase_db.ref("data");

////////////////
// Ethereum setup
const web3 = require("web3");
const Tx = require("ethereumjs-tx").Transaction;

web3js = new web3(new web3.providers.HttpProvider("HTTP://127.0.0.1:7545"));

var myAddress = "0x64443f4EA1d208Af56b68593671A473534359fc1";
var privateKey = Buffer.from(
  "575cbc3b9da4b6241f68e0a48d1167aa9293b8ee37ad58ac99efa550084afa6d",
  "hex"
);
// var toAddress = "0x8Df897D0554729e2E4bf4F7dd1ABBF96bfDe8225";

// read contract data

let contract_data = fs
  .readFileSync(path.join(__dirname, "..", "public/data/contract_data.json"))
  .toString();
contract_data = JSON.parse(contract_data);

//contract abi is the array that you can get from the ethereum wallet or etherscan
var contractABI = contract_data.contractABI;
var contractAddress = contract_data.contractAddress;
//creating contract object
var contract = new web3js.eth.Contract(contractABI, contractAddress);

/////////////////

require("./db/conn");
const Register = require("./models/registers");
const userRegister = require("./models/user");
const Registeruser = require("./models/user");
const authuser = require("./middleware/authuser");
const { timeStamp } = require("console");
// const bcrypt = require("bcryptjs/dist/bcrypt");
// const static_path =
// console.log(path.join(__dirname, "../public"))
const static_path = path.join(__dirname, "../public");
console.log(static_path, "hello");
const templates_path = path.join(__dirname, "../templates/views");
const partials_path = path.join(__dirname, "../templates/partials");

app.use("/public", express.static(static_path));
app.set("view engine", "hbs");
app.set("views", templates_path);
app.use(cookieparser());
hbs.registerPartials(partials_path);
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.get("/", (req, res) => {
  res.render("index");
});

app.get("/firebase", (req, res) => {
  const _id = req.query.id;
});
app.get("/owner", auth, (req, res) => {
  res.render("owner");
});
app.get("/delivery", auth, (req, res) => {
  res.render("delivery");
});
app.get("/buyer", auth, (req, res) => {
  res.render("buyer");
});
app.get("/register", (req, res) => {
  res.render("register");
});
app.get("/login", (req, res) => {
  res.render("login");
});
app.get("/data", (req, res) => {
  res.render("firebase");
});
app.get("/history", (req, res) => {
  res.render("history");
});

app.get("/logout", auth, async (req, res) => {
  try {
    res.clearCookie("jwt");
    console.log("logout successfully");
    await req.user.save();
    // swal("bye!", "LogOut Successfully!", "success");
    res.render("index");
  } catch (error) {
    // swal("bye!", "LogOut Successfully!", "success");
    res.status(500).send(error);
  }
});
app.get("*", (req, res) => {
  res.status(404).render("error");
});

// creating new user on database
app.post("/owner", async (req, res) => {
  const IsEntered = await Register.findOne({ email: req.body.email });
  console.log(req.body);
  if (IsEntered == null) {
    try {
      const password = req.body.password;
      const cpassword = req.body.cpassword;
      if (password === cpassword) {
        const registerOwner = new Register({
          name: req.body.name,
          email: req.body.email,
          password: req.body.password,
          cpassword: req.body.cpassword,
        });

        const token = await registerOwner.generateAuthToken();
        // console.log("token is " + token)

        res.cookie("jwt", token, {
          expires: new Date(Date.now() + 600000),
          httpOnly: true,
        });

        const registered = await registerOwner.save();
        // console.log("token is " + token)
        // swal("Nice!", "Registered Successfully!", "success");
        res.status(201).render("index");
      } else {
        // swal("Oops!", "Registeration UnSuccessfully!", "danger");
        res.send("password not matching");
      }
    } catch (e) {
      res.status(400).send("Something happens");
    }
  } else {
    res.status(400).send("User already Exist");
  }
});

//user register
app.post("/user", async (req, res) => {
  const IsEntered = await userRegister.findOne({ email: req.body.email });
  console.log(req.body);
  if (IsEntered == null) {
    try {
      const password = req.body.password;
      const cpassword = req.body.cpassword;
      if (password === cpassword) {
        console.log("Entered");
        var registeruser = new Registeruser({
          name: req.body.name,
          email: req.body.email,
          password: req.body.password,
          cpassword: req.body.cpassword,
        });

        const token = await registeruser.generateAuthToken();
        // console.log("token is " + token)

        res.cookie("jwt", token, {
          expires: new Date(Date.now() + 600000),
          httpOnly: true,
        });

        const registered = await registeruser.save();
        console.log("token is " + token);
        // swal("Nice!", "Registered Successfully!", "success");
        res.status(201).render("index");
      } else {
        // swal("Oops!", "Registeration UnSuccessfully!", "danger");
        res.send("password not matching");
      }
    } catch (e) {
      res.status(400).send("Something happens");
    }
  } else {
    res.status(400).send("User already Exist");
  }
});

// owner login

app.post("/loginowner", async (req, res) => {
  try {
    const Enteredemail = req.body.email;
    const Enteredpassword = req.body.password;
    const userEmail = await Register.findOne({ email: Enteredemail });
    const isMatch = await bcrypt.compare(Enteredpassword, userEmail.password);
    const token = await userEmail.generateAuthToken();

    // console.log("token is " + token)

    res.cookie("jwt", token, {
      expires: new Date(Date.now() + 650000),
      httpOnly: true,
    });

    if (isMatch) {
      res.status(201).render("index");
    } else {
      swal("OOps!", "Login Unsuccessfull!", "danger");
      res.send("Invalid Credentials");
    }
  } catch (error) {
    console.log(error);
    res.status(400).send("invalid Credentials");
  }
});

// send Sms
app.post("/sendsms", async (req, res) => {
  var prodId = req.body.ProdId;
  var phoneNo = req.body.phoneNo;
  console.log(prodId + " " + phoneNo);
  const response = await fast2sms.sendMessage({
    authorization: process.env.API_KEY,
    message: "YOUR_Prodcut_Id is " + prodId + " Kindly Note it Down",
    numbers: [phoneNo],
  });
  // swal("Nice!", "Sms has been sent Successfully!", "success");
  alert("Nice!,Message has been sent successfully");
  res.render("owner");
});

// Userlogin
app.post("/loginuser", async (req, res) => {
  try {
    const Enteredemail = req.body.email;
    const Enteredpassword = req.body.password;
    const userEmail = await Registeruser.findOne({ email: Enteredemail });
    const isMatch = await bcrypt.compare(Enteredpassword, userEmail.password);
    const token = await userEmail.generateAuthToken2();

    console.log("token is " + token);

    res.cookie("jwt", token, {
      expires: new Date(Date.now() + 650000),
      httpOnly: true,
    });

    if (isMatch) {
      res.status(201).render("index");
    } else {
      // swal("OOps!", "Login Unsuccessfull!", "danger");
      res.send("Invalid Credentials");
    }
  } catch (error) {
    console.log(error);
    res.status(400).send("invalid Credentials");
  }
});

app.listen(port, () => {
  console.log(`server is running on ${port} ~~`);
});

////////////////////

async function waitt() {
  await new Promise((resolve) => setTimeout(resolve, 5000));
}

async function pushData() {
  await waitt();

  firebase_dbref.once("value", (snap) => {
    const data = snap.val();

    console.log(data);
    ////////////////

    var count;

    // get transaction count, later will used as nonce
    web3js.eth.getTransactionCount(myAddress).then(async function (v) {
      count = v;

      let range_arr = [...Array(data.length).keys()];
      for (i of range_arr) {
        const ProdId = data[i].ProdId;
        const humidity = JSON.parse(data[i].humidity);
        const temperature = JSON.parse(data[i].temperature);
        const timestamp = JSON.parse(data[i].timestamp);

        const latitude = JSON.parse(data[i].latitude);
        const longitude = JSON.parse(data[i].longitude);

        var amount = web3js.utils.toHex(1e16);
        //creating raw tranaction
        var rawTransaction = {
          from: myAddress,
          gasPrice: web3js.utils.toHex(40 * 1e9),
          gasLimit: web3js.utils.toHex(3500000),
          to: contractAddress,
          value: "0x0",
          data: contract.methods
            .saveIotData(
              ProdId,
              humidity,
              latitude,
              longitude,
              temperature,
              timestamp
            )
            .encodeABI(),
          nonce: web3js.utils.toHex(count),
        };

        //creating tranaction via ethereumjs-tx
        var transaction = new Tx(rawTransaction);

        //signing transaction with private key
        transaction.sign(privateKey);

        //sending transacton via web3js module
        const result = await web3js.eth.sendSignedTransaction(
          "0x" + transaction.serialize().toString("hex")
        );
        console.log("Count: " + v);
        console.log("status: " + result.status + "\n");

        count += 1;
      }
    });
  });
}

// send IOT data to blockchain after certain interval
setInterval(pushData, 1000);
// pushData();

////////////

// get transaction count, later will used as nonce
// web3js.eth.getTransactionCount(myAddress).then(function (v) {
//   console.log("Count: " + v);
//   count = v;
//   var amount = web3js.utils.toHex(1e16);
//   //creating raw tranaction
//   var rawTransaction = {
//     from: myAddress,
//     gasPrice: web3js.utils.toHex(40 * 1e9),
//     gasLimit: web3js.utils.toHex(350000),
//     to: contractAddress,
//     value: "0x0",
//     data: contract.methods.get_IotData_humidity(11111).encodeABI(),
//     nonce: web3js.utils.toHex(count),
//   };
//   console.log(rawTransaction);
//   //creating tranaction via ethereumjs-tx
//   var transaction = new Tx(rawTransaction);
//   //signing transaction with private key
//   transaction.sign(privateKey);
//   //sending transacton via web3js module

//   // web3js.eth
//   //   .sendSignedTransaction("0x" + transaction.serialize().toString("hex"))
//   //   .on("transactionHash", console.log)
//   //   .on("receipt", function (receipt) {
//   //     console.log(receipt);
//   //     res.json(data[0]);
//   //   });

//   contract.methods
//     .get_IotData_humidity(21321323133)
//     .call()
//     .then(function (data) {
//       console.log(data);
//       res.json(data);
//     });
// });
